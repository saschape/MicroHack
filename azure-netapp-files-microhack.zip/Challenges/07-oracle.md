# Challenge 7: Oracle Databases

Objective: Nutzung von ANF für Oracle.
- Themen: Application Volume Groups.
- Aktivität: Lab für Oracle Volumes.
