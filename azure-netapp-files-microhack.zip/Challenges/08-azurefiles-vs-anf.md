# Challenge 8: Azure Files vs. Azure NetApp Files

Objective: Unterschiede zwischen Azure Files & ANF.
- Vergleichstabelle (Protokolle, Performance, Skalierung, Kosten).
- Aktivität: Diskussion & Fallbeispiele.
