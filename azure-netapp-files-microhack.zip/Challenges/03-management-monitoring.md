# Challenge 3: Managing & Monitoring

Objective: Verwaltung & Monitoring von ANF.
- Themen: Metriken, AD-Integration, Quotas, Backup.
- Aktivität: Lab + Demos.
