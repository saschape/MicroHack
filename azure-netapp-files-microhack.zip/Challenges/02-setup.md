# Challenge 2: Setting Up Azure NetApp Files

Objective: Einrichtung von ANF.
- Themen: Accounts, Pools, Volumes.
- Aktivität: Hands-On Lab (Portal + CLI).
- Guides: `az netappfiles account create` / `pool create` / `volume create`.
