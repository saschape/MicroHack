# Challenge 1: Introduction to Azure NetApp Files

Objective: Überblick, Nutzen und Features von ANF.
- Themen: Performance, Skalierung, Protokolle (SMB/NFS), Use Cases.
- Aktivität: Diskussion + Präsentation.
