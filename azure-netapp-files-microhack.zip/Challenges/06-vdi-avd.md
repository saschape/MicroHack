# Challenge 6: Azure NetApp Files for VDI/AVD

Objective: Nutzung von ANF für virtuelle Desktops.
- Themen: FSLogix, Snapshotting.
- Aktivität: FSLogix Integration + Snapshot Lab.
