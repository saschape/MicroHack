# Challenge 5: Data Protection & Security

Objective: Schutz & Sicherheit in ANF.
- Themen: Snapshots, Encryption, Access Control.
- Aktivität: Snapshots + Policies im Lab.
